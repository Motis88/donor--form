
import React, { useState } from 'react';

export default function App() {
  const [form, setForm] = useState({
    date: '',
    name: '',
    species: '',
    bloodType: '',
    pcv: '',
    htc: '',
    wbc: '',
    plt: '',
    donated: '',
    volume: '',
    packCell: '',
    slide: '',
    notes: '',
    location: ''
  });

  const handleChange = (field, value) => {
    setForm({ ...form, [field]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Submitted:', form);
  };

  return (
    <form onSubmit={handleSubmit} style={{ display: 'grid', gap: '10px', padding: '20px', maxWidth: '500px', margin: 'auto' }}>
      <h2>Donor Form</h2>
      <input type="date" value={form.date} onChange={(e) => handleChange('date', e.target.value)} />
      <input placeholder="Animal Name" value={form.name} onChange={(e) => handleChange('name', e.target.value)} />
      <select value={form.species} onChange={(e) => handleChange('species', e.target.value)}>
        <option value="">Select Species</option>
        <option value="Dog">Dog</option>
        <option value="Cat">Cat</option>
      </select>
      <select value={form.bloodType} onChange={(e) => handleChange('bloodType', e.target.value)}>
        <option value="">Select Blood Type</option>
        <option value="DEA+">DEA+</option>
        <option value="DEA-">DEA-</option>
        <option value="AB">AB</option>
        <option value="A">A</option>
        <option value="B">B</option>
      </select>
      <input placeholder="PCV" value={form.pcv} onChange={(e) => handleChange('pcv', e.target.value)} />
      <input placeholder="HTC" value={form.htc} onChange={(e) => handleChange('htc', e.target.value)} />
      <input placeholder="WBC" value={form.wbc} onChange={(e) => handleChange('wbc', e.target.value)} />
      <input placeholder="PLT" value={form.plt} onChange={(e) => handleChange('plt', e.target.value)} />
      <select value={form.donated} onChange={(e) => handleChange('donated', e.target.value)}>
        <option value="">Donated?</option>
        <option value="Yes">Yes</option>
        <option value="No">No</option>
      </select>
      <input placeholder="Volume (ml)" value={form.volume} onChange={(e) => handleChange('volume', e.target.value)} />
      <input placeholder="Packed Cell" value={form.packCell} onChange={(e) => handleChange('packCell', e.target.value)} />
      <input placeholder="Slide Findings" value={form.slide} onChange={(e) => handleChange('slide', e.target.value)} />
      <textarea placeholder="Notes" value={form.notes} onChange={(e) => handleChange('notes', e.target.value)} />
      <select value={form.location} onChange={(e) => handleChange('location', e.target.value)}>
        <option value="">Select Location</option>
        <option value="Rehovot">Rehovot</option>
        <option value="Petachya">Petachya</option>
        <option value="Holon">Holon</option>
        <option value="Union of Cities Dan">Union of Cities Dan</option>
        <option value="External">External</option>
      </select>
      <button type="submit">Register Donor</button>
    </form>
  );
}
